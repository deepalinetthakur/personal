package com.cg.stepdefinition;

import com.cg.elementlocator.LocateElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefine {

	@Given("^User is on Sign In Page$")
	public void user_is_on_Sign_In_Page() throws Throwable {
		com.cg.pagefact.PageFactory.openbrowser("http://localhost:4200/");

	}

	/*
	 * @When("^User enters wrong credentials$") public void
	 * user_enters_wrong_credentials() throws Throwable {
	 * com.cg.pagefact.PageFactory.insertKeys("multistore@gmail.com",LocateElement.
	 * adminId); Thread.sleep(1000);
	 * com.cg.pagefact.PageFactory.insertKeys("5678",LocateElement.password);
	 * Thread.sleep(1000);
	 * com.cg.pagefact.PageFactory.clickMethod(LocateElement.admin);
	 * Thread.sleep(1000);
	 * com.cg.pagefact.PageFactory.clickMethod(LocateElement.signin);
	 * Thread.sleep(1000); com.cg.pagefact.PageFactory.alertHandler();
	 * Thread.sleep(1000);
	 * com.cg.pagefact.PageFactory.clearBox(LocateElement.adminId);
	 * com.cg.pagefact.PageFactory.clearBox(LocateElement.password);
	 * com.cg.pagefact.PageFactory.clearBox(LocateElement.admin); }
	 */
	@When("^User enters email$")
	public void user_enters_email() throws Throwable {
		com.cg.pagefact.PageFactory.clickMethod(LocateElement.signin);
		Thread.sleep(1000);
		com.cg.pagefact.PageFactory.alertHandler();
		Thread.sleep(1000);
		com.cg.pagefact.PageFactory.insertKeys("admin1@gmail.com", LocateElement.adminId);
	}

	@When("^User enters password$")
	public void user_enters_password() throws Throwable {
		com.cg.pagefact.PageFactory.clickMethod(LocateElement.signin);
		Thread.sleep(1000);
		com.cg.pagefact.PageFactory.alertHandler();
		Thread.sleep(1000);
		com.cg.pagefact.PageFactory.insertKeys("1234", LocateElement.password);
	}

	@When("^User selects category$")
	public void user_selects_category() throws Throwable {
		Thread.sleep(1000);
		com.cg.pagefact.PageFactory.clickMethod(LocateElement.admin);
	}

	@Then("^User clicks on sign in button$")
	public void user_clicks_on_sign_in_button() throws Throwable {
		Thread.sleep(1000);
		com.cg.pagefact.PageFactory.clickMethod(LocateElement.signin);
		Thread.sleep(1000);
		
	}

	@When("^Admin is on show all Customer Page$")
	public void admin_is_on_show_all_Customer_Page() throws Throwable {
		Thread.sleep(1000);
		com.cg.pagefact.PageFactory.clickMethod(LocateElement.showAll);
		Thread.sleep(1000);
	}
	@When("^Admin clicks on delete button$")
	public void admin_clicks_on_delete_button() throws Throwable {
		com.cg.pagefact.PageFactory.clickMethod(LocateElement.delete);
		Thread.sleep(1000);
		//com.cg.pagefact.PageFactory.alertHandler();
	}

	@When("^Customer id deleted$")
	public void customer_id_deleted() throws Throwable {
		Thread.sleep(1000);
		//com.cg.pagefact.PageFactory.close();
	}

}
