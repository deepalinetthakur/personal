package com.cg.pagefact;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class PageFactory 
{
	static WebDriver driver=null;
	public static void openbrowser(String url)
	{
		System.setProperty("webdriver.chrome.driver","./driver/chromedriver.exe");
		driver=new ChromeDriver();
		driver.get(url);
		System.out.println("Browser Opened");
		driver.manage().window().maximize();
	}
	public static void insertKeys(String val,By locator) {
		driver.findElement(locator).sendKeys(val);
	}
	
	public static void clickMethod(By locator) {
		driver.findElement(locator).click();
	}
	
	public static void alertHandler() {
		driver.switchTo().alert().accept();
	}
	public static void close()
	{
		System.out.println("Closing the brower");
		driver.close();
		System.out.println("Browser Closed");
	}
	public static void clearBox(By locator) {
		driver.findElement(locator).clear();
	}
/*	public static void select(By locator,String val)
	{
		WebElement we=driver.findElement(locator);
		Select dd=new Select(we);
		dd.selectByVisibleText(val);
		System.out.println("The drop down value: "+val +" is selected");
	}*/
}
