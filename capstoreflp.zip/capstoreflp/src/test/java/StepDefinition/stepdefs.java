
package StepDefinition;

import Locators.ElementLocator;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import PageFactory.agefactory;
public class stepdefs {

	@Given("^user is on the sign up page$")
	public void user_is_on_the_sign_up_page() throws Throwable {
		PageFactory.agefactory.openbrowser("http://localhost:4200/");
		Thread.sleep(1000);

	}

	@When("^user enters signup$")
	public void user_enters_signup() throws Throwable {
		PageFactory.agefactory.clickmethod(ElementLocator.signup);
	}	

	@When("^user enters name$")
	public void user_enters_name() throws Throwable {
	
		PageFactory.agefactory.insertKeys("capgemini", ElementLocator.name);
		Thread.sleep(1000);
	}

	@When("^user enters email$")
	public void user_enters_email() throws Throwable {
		
		PageFactory.agefactory.insertKeys("capgemini@gmail.com", ElementLocator.email);
		Thread.sleep(1000);


	}

	@When("^user enters phone$")
	public void user_enters_phone() throws Throwable {
		PageFactory.agefactory.insertKeys("7088726514", ElementLocator.number);
		Thread.sleep(1000);

	}

	@When("^user selects customer$")
	public void user_selects_customer() throws Throwable {
		PageFactory.agefactory.select(ElementLocator.merchant);
		PageFactory.agefactory.select(ElementLocator.merchant);

		Thread.sleep(1000);

	}
	
	@When("^user selects aadhar card$")
	public void user_selects_aadhar_card() throws Throwable {
		agefactory.select(ElementLocator.aadharcard);
		Thread.sleep(1000);

	}

	@When("^user enter aadhar number$")
	public void user_enter_aadhar_number() throws Throwable {
		agefactory.insertKeys("1239876459", ElementLocator.aadharnumber);
		Thread.sleep(1000);


	}


	@When("^user enters password$")
	public void user_enters_password() throws Throwable {
		PageFactory.agefactory.insertKeys("1234", ElementLocator.password);
		Thread.sleep(1000);

	}

	@When("^user enters cpassword$")
	public void user_enters_cpassword() throws Throwable {
		PageFactory.agefactory.insertKeys("1234", ElementLocator.cpassword);
		Thread.sleep(3000);
	}

	@When("^user clicks submit$")
	public void user_clicks_submit() throws Throwable {
		Thread.sleep(1000);
		PageFactory.agefactory.clickmethod(ElementLocator.submit);
		PageFactory.agefactory.alertHandler();
		Thread.sleep(1000);


	}

	
	
	
	@When("^user enters emailaddress$")
	public void user_enters_emailaddress() throws Throwable {
		PageFactory.agefactory.insertKeys("capgemini@gmail.com", ElementLocator.emailaddress);
		Thread.sleep(1000);

	}

	@When("^user enters passwrd$")
	public void user_enters_passwrd() throws Throwable {
		
		PageFactory.agefactory.insertKeys("1234", ElementLocator.passwrd);
		Thread.sleep(1000);

	}

	@When("^user selects mrchant$")
	public void user_selects_mrchant() throws Throwable {
		agefactory.clickmethod(ElementLocator.mrchant);
		Thread.sleep(1000);

	}

	@When("^user clicks sign in$")
	public void user_clicks_sign_in() throws Throwable {
		PageFactory.agefactory.clickmethod(ElementLocator.signin);
		Thread.sleep(1000);

	}
	
	@Then("^user clicks ok$")
	public void user_clicks_ok() throws Throwable {
		PageFactory.agefactory.alertHandler();
		Thread.sleep(1000);
	}



}
