
package CucumberOptions;



import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       features = "C:\\Users\\sinegi\\Desktop\\FLP\\capstoreflp\\src\\test\\java\\Features\\cap.feature",
       glue= {"StepDefinition"},
     
       monochrome=true
       //strict=true,
       // tags= {"@SmokeTest,@RegressionTest","~@End2End"},
      // plugin = {"html:target/Destination"}
       )

public class TestRunner {

}
//Please run it through the .feature file
