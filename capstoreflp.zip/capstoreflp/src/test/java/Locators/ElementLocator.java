
package Locators;

import org.openqa.selenium.By;

public class ElementLocator {
	
	public static By signup=By.xpath("//a[text()='Sign Up']");
	public static By name=By.xpath("//input[@ type='text']");
	public static By email=By.xpath("//input[@ type='email']");
	public static By number=By.xpath("//input[@ placeholder='Phone number']");
	public static By merchant=By.xpath("//select");
	public static By aadharcard=By.id("gproof");
	public static By aadharnumber=By.name("govt_id");
	public static By password=By.xpath("//input[@ type='password']");
	

	public static By cpassword=By.xpath("//input[@ placeholder='Confirm password']");
	public static By submit=By.xpath("//button[@ type='submit']");
//	public static By login=By.xpath("//a[text()='Log In']");
	public static By emailaddress=By.xpath("//input [@ placeholder='eg: abc@gmail.com']");

	public static By passwrd=By.id("inputPassword");

	public static By mrchant=By.xpath("//label[@ for='customCheck2']");
	public static By signin=By.xpath("//button[text()='Sign in']");


	
	
	
			
}
